from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__,static_url_path='/static')

# Load the machine learning model
model = pickle.load(open('LaptopPrice.pkl', 'rb'))
@app.route('/')
def home():
    return render_template('index.html')
@app.route('/predict', methods=['POST'])

def predict():
    COMPANY  = str(request.form.get("1"))
    LAPTOP_TYPE=str(request.form.get("2"))
    OPERATING_SYSTEM= str(request.form.get("3"))
    CPU  = str(request.form.get("4"))
    GPU = str(request.form.get("5"))
    RAM = str(request.form.get("6"))
    WEIGHT = float(request.form.get("7"))
    TOUCH_SCREEN = str(request.form.get("8"))
    CLOCK_SPEED= float(request.form.get("9"))
    HDD = float(request.form.get("10"))
    SSD = float(request.form.get("11"))
    PPI = float(request.form.get("12"))
    
    

    # test_input =['Apple','Ultrabook','Mac','Intel','Intel',8,1.37,0,2.3,0.0,0.128,312.781955]#output=71378.6832
    user_input =[
        COMPANY ,LAPTOP_TYPE ,OPERATING_SYSTEM, CPU , GPU, RAM, WEIGHT,TOUCH_SCREEN,CLOCK_SPEED,HDD,SSD,PPI
    ]
    prediction = model.predict(np.array(user_input).reshape(1, -1))
    prediction=str(prediction.round(2))
    print(prediction)

    return render_template("result.html", prediction=prediction,user_input=user_input)

    

if __name__ == "__main__":
    app.run(debug=True)

